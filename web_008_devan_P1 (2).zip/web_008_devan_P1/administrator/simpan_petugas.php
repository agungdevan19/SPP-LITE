<?php
// koneksi database
include '../koneksi.php';

// menangkap data yang di kirim dari form
$username = mysqli_real_escape_string($koneksi,$_POST['username']);
$password = mysqli_real_escape_string($koneksi,$_POST['password']);
$nama_petugas = mysqli_real_escape_string($koneksi,$_POST['nama_petugas']);
$level = mysqli_real_escape_string($koneksi,$_POST['level']);

// menginput data ke database
mysqli_query($koneksi, "insert into petugas values('','$username','$password','$nama_petugas','$level')");

// mengalihkan halaman kembali ke index.php
header("location:petugas.php?info=simpan");