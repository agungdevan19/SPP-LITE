<?php
// koneksi database
include '../koneksi.php';

// menangkap data yang di kirim dari form
$id_petugas =  mysqli_real_escape_string($koneksi,$_POST['id_petugas']);
$username =  mysqli_real_escape_string($koneksi,$_POST['username']);
$password =  mysqli_real_escape_string($koneksi,$_POST['password']);
$nama_petugas =  mysqli_real_escape_string($koneksi,$_POST['nama_petugas']);
$level =  mysqli_real_escape_string($koneksi,$_POST['level']);
// update data ke database
mysqli_query($koneksi, "update petugas set username='$username', password='$password', nama_petugas='$nama_petugas', level='$level' where id_petugas='$id_petugas'");

// mengalihkan halaman kembali ke index.php
header("location:petugas.php?info=update");