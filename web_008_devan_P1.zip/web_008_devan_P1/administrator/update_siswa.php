<?php
// koneksi database
include '../koneksi.php';

// menangkap data yang di kirim dari form
$nisn =  mysqli_real_escape_string($koneksi,$_POST['nisn']);
$nis =  mysqli_real_escape_string($koneksi,$_POST['nis']);
$nama =  mysqli_real_escape_string($koneksi,$_POST['nama']);
$id_kelas =  mysqli_real_escape_string($koneksi,$_POST['id_kelas']);
$alamat =  mysqli_real_escape_string($koneksi,$_POST['alamat']);
$no_telp =  mysqli_real_escape_string($koneksi,$_POST['no_telp']);
$id_spp =  mysqli_real_escape_string($koneksi,$_POST['id_spp']);
// update data ke database
mysqli_query($koneksi, "update siswa set nis='$nis', nama='$nama', id_kelas='$id_kelas', alamat='$alamat', no_telp='$no_telp', id_spp='$id_spp' where nisn='$nisn'");

// mengalihkan halaman kembali ke index.php
header("location:siswa.php?info=update");
