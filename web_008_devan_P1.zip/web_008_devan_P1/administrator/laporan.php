<?php
session_start();

// cek apakah yang mengakses halaman ini sudah login
if ($_SESSION['level'] == "") {
    header("location:../login.php?info=login");
}

?>
<?php
include '../layouts/header.php';
include '../layouts/navbar.php';
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Laporan Pembayaran</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container">
            <div class="col-lg-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-6">
                                <h6>Data Laporan Pembayaran</h6>
                            </div>
                            <div class="col-6 text-right">
                                <a href="print_laporan.php" class="btn btn-primary btn-sm" target="_blank"><i class="fas fa-print"></i> Print Laporan</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php
                        if (isset($_GET['info'])) {
                            if ($_GET['info'] == "hapus") { ?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h5><i class="icon fas fa-trash"></i> Sukses</h5>
                                    Data berhasil di hapus
                                </div>
                            <?php } else if ($_GET['info'] == "simpan") { ?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h5><i class="icon fas fa-check"></i> Sukses</h5>
                                    Data berhasil di simpan
                                </div>
                            <?php } else if ($_GET['info'] == "update") { ?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h5><i class="icon fas fa-edit"></i> Sukses</h5>
                                    Data berhasil di update
                                </div>
                        <?php }
                        } ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Nama Siswa</th>
                                    <th>SPP</th>
                                    <th>Sisa Bayar</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                include "../koneksi.php";
                                $siswa    = mysqli_query($koneksi, "SELECT * FROM siswa INNER JOIN kelas ON siswa.id_kelas=kelas.id_kelas INNER JOIN spp ON siswa.id_spp=spp.id_spp");
                                while ($d_siswa = mysqli_fetch_array($siswa)) {
                                    $data_pembayaran = mysqli_query($koneksi, "select SUM(jumlah_bayar) as jumlah_bayar FROM pembayaran where nisn='$d_siswa[nisn]'");
                                    $data_pembayaran = mysqli_fetch_array($data_pembayaran);
                                    $sudah_bayar = $data_pembayaran['jumlah_bayar'];
                                    $kekurangan = $d_siswa['nominal'] - $data_pembayaran['jumlah_bayar'];
                                ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?= $d_siswa['nama'] ?></td>
                                        <td>Tahun <?= $d_siswa['tahun'] ?> Nominal Rp. <?= number_format($d_siswa['nominal']) ?></td>
                                        <td>
                                            <?php if ($kekurangan == '') { ?>
                                                0
                                            <?php } else { ?>
                                                Rp. <?php echo number_format($kekurangan); ?>
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <?php if ($d_siswa['nominal'] == $sudah_bayar) { ?>
                                                <div class="btn btn-success btn-sm">Lunas</div>
                                            <?php } else { ?>
                                                <div class="btn btn-warning btn-sm">Belum Lunas</div>
                                            <?php } ?>
                                        </td>
                                        <div class="modal fade" id="modal-edit">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Lihat Data Pembayaran</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form>
                                                            <div class="form-group">
                                                                <label>Nama Siswa</label>
                                                                <select name="id_kelas" class="form-control">
                                                                    <option>=== Pilih Siswa ===</option>
                                                                    <option> option 2</option>
                                                                    <option> option 3</option>
                                                                    <option> option 4</option>
                                                                    <option> option 5</option>
                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>SPP</label>
                                                                <select name="id_kelas" class="form-control">
                                                                    <option>=== Pilih SPP ===</option>
                                                                    <option> option 2</option>
                                                                    <option> option 3</option>
                                                                    <option> option 4</option>
                                                                    <option> option 5</option>
                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Jumlah Bayar</label>
                                                                <input type="text" name="jumlah_bayar" class="form-control" placeholder="Masukkan Jumlah Bayar">
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                                                                <button type="button" class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                    </div>

                    <div class="modal fade" id="modal-hapus">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Hapus Data Siswa</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Apakah Anda Yakin Akan Menghapus Data ini !!!&hellip;</p>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                                    <button type="button" class="btn btn-primary">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <div class="modal fade" id="modal-tambah">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Tambah Data Siswa</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form role="form">
                                    <div class="form-group">
                                        <label>Nama Siswa</label>
                                        <select name="id_kelas" class="form-control">
                                            <option>=== Pilih Siswa ===</option>
                                            <option> option 2</option>
                                            <option> option 3</option>
                                            <option> option 4</option>
                                            <option> option 5</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>SPP</label>
                                        <select name="id_kelas" class="form-control">
                                            <option>=== Pilih SPP ===</option>
                                            <option> option 2</option>
                                            <option> option 3</option>
                                            <option> option 4</option>
                                            <option> option 5</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Jumlah Bayar</label>
                                        <input type="text" name="jumlah_bayar" class="form-control" placeholder="Masukkan Jumlah Bayar">
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                                        <button type="button" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                </tbody>
                </table>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php
include '../layouts/footer.php';
?>